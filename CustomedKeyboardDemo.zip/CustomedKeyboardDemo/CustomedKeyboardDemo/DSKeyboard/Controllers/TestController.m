//
//  TestController.m
//  CustomedKeyboardDemo
//
//  Created by 宋利军 on 16/3/5.
//  Copyright © 2016年 HouBank. All rights reserved.
//

#import "TestController.h"
#import "DSKyeboard.h"

#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)

@interface TestController ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *tf0;
@property (nonatomic, strong) UITextField *tf;
@property (nonatomic, strong) UILabel *passwrodLab;

@end

@implementation TestController

#pragma mark - lazy loading
- (UITextField *)tf0 {
    if (!_tf0) {
        _tf0 = [[UITextField alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.navigationController.navigationBar.frame) + 20, kScreenWidth - 2 * 20, 30)];
        _tf0.delegate = self;
        _tf0.borderStyle = UITextBorderStyleRoundedRect;
        _tf0.backgroundColor = [UIColor whiteColor];
        _tf0.placeholder = @"请输入账号";
        [self.view addSubview:_tf0];
    }
    return _tf0;
}

- (UITextField *)tf {
    if (!_tf) {
        _tf = [[UITextField alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.tf0.frame) + 20, kScreenWidth - 2 * 20, 30)];
        _tf.delegate = self;
        _tf.borderStyle = UITextBorderStyleRoundedRect;
        _tf.clearButtonMode = UITextFieldViewModeWhileEditing;
        _tf.backgroundColor = [UIColor whiteColor];
        _tf.placeholder = @"请输入密码";
        [self.view addSubview:_tf];
    }
    return _tf;
}

- (UILabel *)passwrodLab {
    if (!_passwrodLab) {
        _passwrodLab = [[UILabel alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(self.tf.frame) + 20, kScreenWidth - 2 * 20, 30)];
        _passwrodLab.backgroundColor = [UIColor whiteColor];
        _passwrodLab.textAlignment = NSTextAlignmentCenter;
        _passwrodLab.layer.cornerRadius = 5.0;
        _passwrodLab.layer.masksToBounds = YES;
        [self.view addSubview:_passwrodLab];
    }
    return _passwrodLab;
}

#pragma mark - loading view
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    [self setupCustomedKeyboard];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    [self passwrodLab];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [self.view endEditing:YES];
//}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField != self.tf) {
        [self setupCustomedKeyboard];
    }
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField {}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    if (textField == self.tf) {
        [(DSKyeboard *)self.tf.inputView clear];
    }
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return YES;
}

- (void)setupCustomedKeyboard {
    self.tf.inputView = [DSKyeboard keyboardWithTextField:self.tf];
    
    __weak typeof(self) weakSelf = self;
    [(DSKyeboard *)self.tf.inputView dsKeyboardTextChangedOutputBlock:^(NSString *fakePassword) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.tf.text = fakePassword;
    } loginBlock:^(NSString *password) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        strongSelf.passwrodLab.text = [NSString stringWithFormat:@"密码 : %@", password];
    }];
}
@end
